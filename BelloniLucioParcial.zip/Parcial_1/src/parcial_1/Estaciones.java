
package parcial_1;

public enum Estaciones {
    PRIMAVERA,
    VERANO,
    OTONIO,
    INVIERNO
}
