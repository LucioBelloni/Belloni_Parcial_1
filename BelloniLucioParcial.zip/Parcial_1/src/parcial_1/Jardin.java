
package parcial_1;

import java.util.ArrayList;
import java.util.List;


public class Jardin {
    
    private String nombre;
    private List <Planta> listaPlanta;

    public Jardin(String nombre){
        this.nombre = nombre;
        this.listaPlanta = new ArrayList<>();
    }
    
    
    
    public void agregarPlanta(Planta planta)
    {
       if(planta == null)
       {
         throw  new NullPointerException("Me pasaste un null en lugar de una planta");
       }
       if(listaPlanta.contains(planta)){
           throw  new PlantaRepetidoExepcion();
       }
       listaPlanta.add(planta);
      
    } 
    
    
     public void mostrarPlantas(){
        if(listaPlanta.isEmpty()){
            System.out.println("La lista de plantas esta vacia....");
        }
        for(Planta p: listaPlanta){
                System.out.println(p);
            }
    }
    
    public void podarPlantas(){
        for(Planta p: listaPlanta){
            if(p.puedePodarse()){
                System.out.println("Estamos podando el " + p.getNombre());
            }
            else{
                System.out.println("Las flores no pueden podarse.");
            }
        }
    }
    
    
    
    
   
    
    
}
