
package parcial_1;


public class Flor  extends Planta{
    private Estaciones temporadaFloreciento;

    public Flor(String nombre, String ubicacion, String clima, Estaciones temporadaFloreciento) {
        super(nombre, ubicacion, clima);
        this.temporadaFloreciento = temporadaFloreciento;
        
    }
    
    @Override
    public String toString() {
        return super.toString() + "temporadaFloreciento: " + temporadaFloreciento;
    }

    @Override
    public boolean puedePodarse() {
        return  false;
    }
    
    
    
    
}
