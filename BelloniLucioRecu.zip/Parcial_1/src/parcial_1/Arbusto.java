
package parcial_1;


public class Arbusto extends Planta implements Podable{
    private int densidadFollaje;
    private static final int MIN_DENSIDAD = 1;
    private static final int MAX_DENSIDAD = 10;
    
    
    public Arbusto(String nombre, String ubicacion, String clima, int desidadaFollaje) {
        super(nombre, ubicacion, clima);
        validarDensidad(desidadaFollaje);
        this.densidadFollaje = desidadaFollaje;
    }

    private boolean validarDensidad(int densidadFollaje){
        if(densidadFollaje >= MIN_DENSIDAD && densidadFollaje <= MAX_DENSIDAD){
            return true;
        }
        throw new IllegalArgumentException("me pasaste un numero mas grande que el 10");
    }

    @Override
    public String toString() {
        return super.toString()  + "densidadFollaje: " + densidadFollaje;
    }

    @Override
    public void podar() {
        System.out.println("El Arbusto se esta podando");
    }
    
    
    
    
}
