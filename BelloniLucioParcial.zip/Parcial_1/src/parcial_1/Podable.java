
package parcial_1;


public interface Podable {
    
     void podar();
     
}
