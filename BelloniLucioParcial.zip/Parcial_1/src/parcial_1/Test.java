
package parcial_1;


public class Test {

    
    public static void main(String[] args) {
        
        Jardin botanico = new Jardin("Jardin botanico Buenos Aires");
        
        try{
            
            botanico.agregarPlanta(new Flor("asd", "adas", "humedo", Estaciones.PRIMAVERA));
            botanico.agregarPlanta(new Arbol("Roble", "Norte", "seco", 12));
            botanico.agregarPlanta(new Arbol("Alamo", "Norte", "humedo", 10));
            botanico.agregarPlanta(new Arbusto("Jazmin", "Sur", "humedo", 20));
           
            
        } 
        catch (RuntimeException e) {
            System.out.println(e.getMessage());    
        }
        
        botanico.mostrarPlantas();
        botanico.podarPlantas();
        

    }
    
}
